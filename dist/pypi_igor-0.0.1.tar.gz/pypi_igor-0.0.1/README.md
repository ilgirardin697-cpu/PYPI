# Hola Mundo con PySide6
 
Este paquete muestra una ventana con un mensaje "Hola mundo" usando PySide6.
 
## Instalación
 
```bash
pip install pypi_tunombre