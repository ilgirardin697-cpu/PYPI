def main():
    """Wrapper entry point that imports `hola_mundo`.

    `hola_mundo` currently runs the GUI at import time, so importing it is
    enough to launch the application.
    """
    import hola_mundo
